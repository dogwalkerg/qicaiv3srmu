<?php

namespace App\Models;

/**
 * Ann Model
 */

use App\Utils\Tools;

class Ann extends Model
{
    protected $connection = "default";
    protected $table = "announcement";
}
